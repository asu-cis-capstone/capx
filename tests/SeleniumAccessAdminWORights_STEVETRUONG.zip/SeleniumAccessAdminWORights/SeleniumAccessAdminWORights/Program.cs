﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace SeleniumAccessAdminWORights
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new FirefoxDriver();

            driver.Navigate().GoToUrl("http://www.cis440.com/");
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://www.cis440.com/login");

            IWebElement gitUserName = driver.FindElement(By.Id("login_field"));
            gitUserName.SendKeys("[NON ADMIN USERNAME]");

            IWebElement gitPass = driver.FindElement(By.Id("password"));
            gitPass.SendKeys("[NON ADMIN PASSWORD]");
            gitPass.SendKeys(Keys.Enter);

            driver.Navigate().GoToUrl("http://www.cis440.com/adminPromote");

            if (driver.PageSource.Contains("Admin"))
            {
                driver.Close();
                Console.WriteLine("User accessed admin panel without sufficient rights.");
            }
            else
            {
                driver.Close();
                Console.WriteLine("User was unable to access admin rights because they had incorrect permissions.");
            }

            Console.ReadLine();
            
        }
    }
}
