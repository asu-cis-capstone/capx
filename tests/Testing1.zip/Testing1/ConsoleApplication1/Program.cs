﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool projectdesclength = false;

            IWebDriver driver = new FirefoxDriver();

            driver.Navigate().GoToUrl("http://www.cis440.com/");
            driver.Navigate().GoToUrl("http://www.cis440.com/addproject");
            driver.Manage().Window.Maximize();

            IWebElement first_Name = driver.FindElement(By.Name("firstname"));
            first_Name.SendKeys("Sneha");

            IWebElement last_Name = driver.FindElement(By.Name("lastname"));
            last_Name.SendKeys("Dadhania");

            IWebElement email_Input = driver.FindElement(By.Name("email"));
            email_Input.SendKeys("sdadhania@cox.net");

            IWebElement phone_No = driver.FindElement(By.Name("phone"));
            phone_No.SendKeys("24689013575");

            IWebElement company_Name_Input = driver.FindElement(By.Name("company"));
            company_Name_Input.SendKeys("XYZABC ");

            IWebElement project_Name = driver.FindElement(By.Name("project"));
            project_Name.SendKeys("Release 6 testing");

            IWebElement project_Description = driver.FindElement(By.Name("comment"));
            project_Description.SendKeys("This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012.This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012. This is testing for the release # 6 for CIS 440 Capstone Project. This testing is done using Selenium and Visual Studio 2012.   ");
            if (project_Description.Text.Length >= 300)
            {
//  Console.WriteLine("Invalid Input and Length of");
                projectdesclength = true;
            }

            if (driver.PageSource.Contains("Release 6 testing"))
            {

                project_Description.SendKeys("Invalid Input and Length of ");

            }
            Console.ReadLine();


        }
    }
}
