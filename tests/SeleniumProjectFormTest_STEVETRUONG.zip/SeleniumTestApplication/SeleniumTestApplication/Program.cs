﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace SeleniumTestApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            bool emailContains = false;
            bool phoneLength = false;

            IWebDriver driver = new FirefoxDriver();

            driver.Navigate().GoToUrl("http://www.cis440.com/");
            driver.Navigate().GoToUrl("http://www.cis440.com/addproject");
            driver.Manage().Window.Maximize();

            IWebElement firstName = driver.FindElement(By.Name("firstname"));
            firstName.SendKeys("Steve");

            IWebElement lastName = driver.FindElement(By.Name("lastname"));
            lastName.SendKeys("Truong");

            IWebElement emailInput = driver.FindElement(By.Name("email"));
            emailInput.SendKeys("testing");
            if (emailInput.Text.Contains("@"))
            {
                if (emailInput.Text.Contains(".com") || emailInput.Text.Contains(".edu"))
                {
                    emailContains = true;
                }
            }

            IWebElement phoneInput = driver.FindElement(By.Name("phone"));
            phoneInput.SendKeys("123457867890");
            if (phoneInput.Text.Length == 10)
            {
                phoneLength = true;
            }

            IWebElement companyInput = driver.FindElement(By.Name("company"));
            companyInput.SendKeys("Selenium Test");

            IWebElement projName = driver.FindElement(By.Name("project"));
            projName.SendKeys("Automated Testing with Selenium");

            IWebElement projDesc = driver.FindElement(By.Name("comment"));
            projDesc.SendKeys("This is a Selenium test created with Visual Studios 2013 in the C# programming language");
            
            firstName.SendKeys(Keys.Enter);

            driver.Navigate().GoToUrl("http://www.cis440.com/");
            driver.Navigate().GoToUrl("http://www.cis440.com/login");

            IWebElement gitUserName = driver.FindElement(By.Id("login_field"));
            gitUserName.SendKeys("[ADMIN USER NAME]");

            IWebElement gitPass = driver.FindElement(By.Id("password"));
            gitPass.SendKeys("[ADMIN PASSWORD]");
            gitPass.SendKeys(Keys.Enter);

            if (driver.Title.Contains("CAPx"))
            {
                driver.Navigate().GoToUrl("http://www.cis440.com/");
                driver.Navigate().GoToUrl("http://www.cis440.com/adminProject");
            }

            if (driver.PageSource.Contains("Selenium Test"))
            {
                driver.Close();
                if (emailContains == false)
                {
                    Console.WriteLine("Invalid email has passed validation\n");
                }

                if (phoneLength == false)
                {
                    Console.WriteLine("Invalid phone number has passed validation");
                }
                Console.ReadLine();
            }

        }
    }
}
